## Default Assets
* This folder is copy of `@eo-sdk\client\assets` and it will be automatically updated based on  `@eo-sdk/client` version
